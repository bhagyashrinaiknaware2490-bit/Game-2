Lagoon Strike - Android project
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > select this LagoonStrikeAPK folder, wait for Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   The APK appears in app/build/outputs/apk/debug/app-debug.apk
4. Copy it to your phone and install (allow "install unknown apps").
The full-quality 4096px city (city.glb) is bundled inside, so there is no size limit.
The phone needs internet on first launch to fetch three.js from a CDN.
